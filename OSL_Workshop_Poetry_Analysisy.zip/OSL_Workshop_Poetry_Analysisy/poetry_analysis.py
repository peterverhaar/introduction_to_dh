

import urllib.request
import urllib.parse
import xml.etree.ElementTree as ET
import re
import os
import string
from nltk import word_tokenize
import nltk
from nltk.stem import WordNetLemmatizer


class poem:

    full_text = ''
    file_name = ''
    nr_tokens = 0
    nr_types = 0
    nr_stanzas = 0
    nr_lines = 0


    lines = dict()
    transcriptions = dict()


    def __init__(self, file_name ):
        self.file_name = file_name

        nr_lines = 0
        nr_words = 0
        nr_stanzas = 0
        stanza_structure = dict()

        tokens_count = 0
        if re.search( r'\.xml$' , self.file_name ):
            if 3 < 4:

                ns = {'tei': 'http://www.tei-c.org/ns/1.0' }

                with open( file_name , encoding = 'utf-8' ) as file:
                    xml = file.read()

                root = ET.fromstring(xml)
                tei_text = root.find('tei:text/tei:body' , ns )
                stanzas = tei_text.findall('tei:lg' , ns )

                line_elements = []
                full_text = dict()
                transcriptions = dict()
                breaks = []

                if len(stanzas) > 0:
                    nr_stanzas = len(stanzas)
                    for s in stanzas:
                        breaks.append( nr_lines + 1 )
                        lines = s.findall('tei:l' , ns )
                        for l in lines:
                            nr_lines += 1
                            line_elements.append(l)
                else:
                    lines = tei_text.findall('tei:l' , ns )
                    for l in lines:
                        nr_lines += 1
                        line_elements.append(l)

                for l in line_elements:
                    n_line = l.get('n')
                    n_line = int(n_line)
                    line_text = ''
                    transcription = ''
                    words = l.findall('tei:w' , ns )
                    for w in words:
                        if re.search( r'\w+', str(w.text) ):
                            line_text += ' '
                        line_text += w.text
                        transcription += w.get('phon') + ' '
                    full_text[ n_line ] = line_text.strip()
                    transcriptions[ n_line ] = transcription.strip()
                    words = word_tokenise( full_text[ n_line ] )
                    nr_words += len(words)

            #except:
            #    print( "Cannot read " + self.file_name + " !" )

            #self.nr_types = len(freq)
            self.nr_words = nr_words
            self.nr_stanzas = nr_stanzas
            self.nr_lines = nr_lines

            structure = dict()

            stanza_count = 0
            stanza_lines = []
            for i in range(1, nr_lines+1):
                if i in breaks:
                    if len(stanza_lines) > 0:
                        stanza_count += 1
                        structure[stanza_count] = stanza_lines
                        stanza_lines = []
                stanza_lines.append(i)
            if len(stanza_lines) > 0:
                stanza_count += 1
                structure[stanza_count] = stanza_lines
                stanza_lines = []

            self.stanza_structure = structure


            self.lines = full_text

            complete_full_text = ''
            for l in full_text:
                complete_full_text += full_text[l] + ' '
            self.full_text = complete_full_text.strip()
            self.transcriptions = transcriptions

    def __str__(self):
        return f'The text contains the contents of { self.file_name }'

    def title( self ):
        title = os.path.basename( self.file_name )
        title = re.sub( r'[.]txt$' , '' , title )
        return title

    def tokens( self ):
        return self.tokens



# function to tokenise a string into words
def word_tokenise( text ):
    tokens = []
    text = text.lower()
    text = re.sub( '--' , ' -- ' , text)
    words = re.split( r'\s+' , text )
    for w in words:
        w = w.strip( string.punctuation )
        if re.search( r"[a-zA-Z]" , w ):
            tokens.append(w)
    return tokens


consonants = "b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|z|D|Z|S|T|N"
vowels = "{|@|V|I|e|Q|U"
diphthongs = "aU|@U|a:|3:|i:|u:|O:|eI|aI|oI|@U|e@|I@|U@|dZ|tS"


def separatePhonemes( text ):
    phonemes = []
    text = re.sub( r'\s+' , '' , text )
    text = re.sub( r'!' , '' , text )
    text = re.sub( r'%' , '' , text )

    consonants = "bdfghjklmnprstvwzSZDT"

    regex = r'aU|@U|a:|3:|i:|u:|O:|eI|aI|oI|@U|e@|I@|U@|dZ|tS'
    regex += '|[{}]'.format(consonants)
    regex += '|[{}]'.format(vowels)

    phonemes = re.findall( regex , text )
    return phonemes


def finalPhonemeSequence( word ):
    rhyme = finalStressedSyllable( word )
    rhyme = re.sub( r'^[{}]+'.format(consonants) , '' , rhyme )
    return rhyme


def finalPhonemeSequence_line( line ):
    words = re.split( r'\s+' , line )
    last_word = words[-1]
    fps = finalPhonemeSequence(last_word)
    return fps

def finalStressedSyllable( word ):
    word = re.sub( r'\*' , '!' , word )
    parts = re.split( r'!' , word )
    rhyme = parts[-1]
    rhyme = re.sub( r'!' , '' , rhyme )
    return rhyme

def is_vowel( phoneme ):

    regex = r'{}|{}'.format( diphthongs , vowels )

    if re.search( regex , phoneme ):
        return True
    else:
        return False

def is_consonant( phoneme ):

    if re.search( r'[{}]'.format(consonants) , phoneme ):
        return True
    else:
        return False



def ptb_to_wordnet(PTT):

    if PTT.startswith('J'):
        ## Adjective
        return 'a'
    elif PTT.startswith('V'):
        ## Verb
        return 'v'
    elif PTT.startswith('N'):
        ## Noune
        return 'n'
    elif PTT.startswith('R'):
        ## Adverb
        return 'r'
    else:
        return ''


lemmatiser = WordNetLemmatizer()


## Read pronunication dictionary
pronunciation_dict = dict()


tei_start = '''<?xml version="1.0" encoding="UTF-8"?>
<?xml-model href="http://www.tei-c.org/release/xml/tei/custom/schema/relaxng/tei_all.rng" type="application/xml" schematypens="http://relaxng.org/ns/structure/1.0"?>
<?xml-model href="http://www.tei-c.org/release/xml/tei/custom/schema/relaxng/tei_all.rng" type="application/xml"
	schematypens="http://purl.oclc.org/dsdl/schematron"?>
<TEI xmlns="http://www.tei-c.org/ns/1.0">
  <teiHeader>
      <fileDesc>
         <titleStmt>
            <title>Title</title>
         </titleStmt>
         <publicationStmt>
            <p>Publication Information</p>
         </publicationStmt>
         <sourceDesc>
            <p>Information about the source</p>
         </sourceDesc>
      </fileDesc>
  </teiHeader><text>
      <body>'''

tei_end =	'''</body>
		   </text>
		</TEI>
		'''


def encodeFileName(text):
	text = re.sub( r'[\'`]' , '&#x27;' , text)
	text = re.sub( r'\s+' , '_' , text)
	return text



def encode_line(line):
    encoded_line = ''
    words = word_tokenize(line)
    pos = nltk.pos_tag(words)
    for i in range( 0 , len(words) ):
        if re.search( r'\w' , words[i] ):
            encoded_line += '\n<w '
            word = words[i]
            encoded_line += f'pos="{pos[i][1]}" '
            lemma = ''
            posTag = ptb_to_wordnet( pos[i][1] )
            if re.search( r'\w+' , posTag , re.IGNORECASE ):
                lemma = lemmatiser.lemmatize( words[i] , posTag )
            else:
                lemma = lemmatiser.lemmatize( words[i] )
            encoded_line += f'lemma="{lemma}" '
            transcr = pronunciation_dict.get( word.lower() , "" )
            transcr = re.sub( r'["]' , '!' , transcr )
            encoded_line += f'phon="{ transcr  }" '
            encoded_line += '>'
            encoded_line += f'{ word }</w> '
        else:
            encoded_line = encoded_line.strip() + words[i]
    return encoded_line



def add_annotations(file_name):

    if len(pronunciation_dict) == 0:
        file = open('pronunciationDictionary.txt' , encoding = 'utf-8')
        for line in file:
            parts = re.split( r'\t' , line )
            pronunciation_dict[ parts[0] ] = parts[1]

    print( f'Adding annotations for {file_name} ... ')


    with open( file_name , encoding  = 'utf-8') as fh:
    	full_text = fh.read()
    	full_text = full_text.strip()

    segments = re.split( r'\n' , full_text )
    title = segments[0]
    del segments[0]

    lines = dict()
    n_line = 0
    n_stanza = 0
    open_stanza = False

    body = ''
    for index in range( 0 , len(segments) ):
        line = segments[index]
        if re.search( r'.' , line):
            ## remove entities
            line = re.sub( r'&\w+;' , '' , line )
            n_line += 1
            body += f'\n<l n="{n_line}">{ encode_line(line) }</l>'
        else:
            if n_line > 0:
                body += '</lg>'
            n_stanza += 1
            body += f'\n<lg n="s{n_stanza}">'

    body += '\n</lg>'

    tei_full = tei_start
    tei_full += f'<head><title>{title}</title></head>'
    tei_full += body
    tei_full += tei_end

    return tei_full




## Literary devices

def alliteration(tr_line):
    scheme = ''
    sounds_start = dict()
    alliterations = []

    pattern_list = []
    words = re.split( r'\s+' , tr_line )

    #words = set( words )

    for w in words:
        if re.search( r'!' , w):
            syllables = re.split( '-' , w )
            for s in syllables:
                if re.search( r'^!' , s):
                    phonemes = separatePhonemes(s)
                    pattern_list.append( phonemes[0] )
                    sounds_start[ phonemes[0] ] = sounds_start.get( phonemes[0] , 0) +1
        else:
            pattern_list.append( '-' )

    for s in sounds_start:
        if sounds_start[s] > 1:
            alliterations.append(s)

    pattern = ''
    for p in pattern_list:
        if p in alliterations:
            pattern += f'{p} '
        else:
            pattern += '- '

    return pattern



## Rhyme

def perfect_rhyme( stanza ):
    # input: list of transcibed lines
    # these lines form a stanza

    # dict used to tarce repeated words
    ## repeated words are not rhymes
    word_count = dict()
    sounds_freq = dict()
    stanza_pattern = []

    for l in stanza:
        ## find last word
        words = re.split( r'\s+' , l )
        last_word = words[-1]
        fps = finalPhonemeSequence(last_word)
        ## repeated words are not rhymes
        word_count[last_word] = word_count.get( last_word , 0) + 1
        if word_count[last_word] == 1:
            sounds_freq[fps] = sounds_freq.get(fps,0)+1
            stanza_pattern.append(fps)
        else:
            stanza_pattern.append('-')


        rhyming_scheme = ''
        code = 0
        code_dict = dict()
        for line in stanza_pattern:
            if sounds_freq.get(line,0) > 1 and line not in code_dict:
                code += 1
                code_dict[line] = code

            if line in code_dict:
                rhyming_scheme += str(code_dict[line]) + ' '
            else:
                rhyming_scheme += '- '

    return rhyming_scheme



def line_ending(line):

    fps = finalPhonemeSequence_line(line)

    if re.search( r'-' , fps ):
        return 'F'
    else:
        return 'M'



def internal_rhyme( line ):
    internal_rhymes = []
    sounds_freq = dict()
    words = re.split( r'\s+' , line )

    ## deduplicate the words
    words = list( set(words) )

    for word in words:
        if re.search('!' , word ):
            fps = finalPhonemeSequence(word)
            sounds_freq[fps] = sounds_freq.get(fps,0) + 1

    for s in sounds_freq:
        if sounds_freq[s] > 1:
            internal_rhymes.append(s)

    ## potential improvement: only in stressed syllables?
    return internal_rhymes



def slant_rhyme_consonance( stanza ):

    stanza_pattern = []
    sounds_freq = dict()
    words_freq = dict()
    word_pattern = dict()

    for l in stanza:
        words = re.split( r'\s+' , l )
        last_word = words[-1]

        phonemes = separatePhonemes(last_word)
        pattern = ''
        for ph in phonemes:
            if is_vowel(ph):
                pattern += '-'
            else:
                pattern += ph

        ## connect word to pattern
        word_pattern[last_word] = pattern

        sounds_freq[ pattern ] = sounds_freq.get( pattern , 0 ) + 1
        words_freq[ last_word ] = words_freq.get( last_word , 0 ) + 1
        stanza_pattern.append(last_word)

    rhyming_scheme = ''
    code = 0
    code_dict = dict()
    for line in stanza_pattern:
        pattern = word_pattern[line]

        if words_freq[line] == 1 and sounds_freq.get(pattern,0) > 1:

            if pattern not in code_dict:
                code += 1
                code_dict[pattern] = code

        if pattern in code_dict:
            rhyming_scheme += str(code_dict[pattern]) + ' '
        else:
            rhyming_scheme += '- '

    return rhyming_scheme



def slant_rhyme_assonance( stanza ):

    stanza_pattern = []
    sounds_freq = dict()
    perfect_rhyme = dict()
    words_freq = dict()
    fps_freq = dict()
    word_pattern = dict()

    for l in stanza:
        words = re.split( r'\s+' , l )
        last_word = words[-1]
        fps = finalPhonemeSequence(last_word)

        fps_freq[last_word] = fps_freq.get(last_word,0) +1
        words_freq[ last_word ] = words_freq.get( last_word , 0 ) + 1
        stanza_pattern.append(last_word)

        if words_freq[last_word] == 1:
            perfect_rhyme[fps] = perfect_rhyme.get(fps,0)+1

        phonemes = separatePhonemes(last_word)
        pattern = ''
        for ph in phonemes:
            if is_consonant(ph):
                pattern += '-'
            else:
                pattern += ph

        word_pattern[last_word] = pattern
        sounds_freq[ pattern ] = sounds_freq.get( pattern , 0 ) + 1


        # Ignore the perfect rhymes

    for r in perfect_rhyme:
        if perfect_rhyme[r] > 1:
            phonemes = separatePhonemes(r)
            pattern = ''
            for ph in phonemes:
                if is_consonant(ph):
                    pattern += '-'
                else:
                    pattern += ph


            for sound in sounds_freq:
                if re.search( r'{}$'.format(pattern) , sound ):
                    sounds_freq[sound] = sounds_freq[sound] - (perfect_rhyme[r] -1)

    rhyming_scheme = ''
    code = 0
    code_dict = dict()
    for line in stanza_pattern:
        pattern = word_pattern[line]

        if words_freq[line] == 1 and sounds_freq.get(pattern,0) > 1:

            if pattern not in code_dict:
                code += 1
                code_dict[pattern] = code

        if pattern in code_dict:
            rhyming_scheme += str(code_dict[pattern]) + ' '
        else:
            rhyming_scheme += '- '



    return rhyming_scheme


def semi_rhyme( stanza ):

    word_count = dict()
    sounds_freq = dict()
    stanza_pattern = []

    for line in stanza:
        words = re.split( r'\s+' , line )
        last_word = words[-1]
        fps = finalPhonemeSequence( last_word )
        if re.search( r'-' , fps ):
            print(fps)
            fps = fps[ : fps.index('-') ]
            print(fps)

        word_count[last_word] = word_count.get( last_word , 0) + 1
        if word_count[last_word] == 1:
            sounds_freq[fps] = sounds_freq.get(fps,0)+1
            stanza_pattern.append(fps)
        else:
            stanza_pattern.append('-')


        rhyming_scheme = ''
        code = 0
        code_dict = dict()
        for line in stanza_pattern:
            if sounds_freq.get(line,0) > 1 and line not in code_dict:
                code += 1
                code_dict[line] = code

            if line in code_dict:
                rhyming_scheme += str(code_dict[line]) + ' '
            else:
                rhyming_scheme += '- '

    return rhyming_scheme


def anaphora( stanza ):
    ## only the unique lines need to be considered
    stanza = set(stanza)
    for line in stanza:
        print(line)
