var mapp_data = {
    "type": "FeatureCollection",
    "features": [
        {
            "type": "Feature",
            "properties": {
                "recipient": "A. R. Moon Esq.",
                "address": "46 Redhill Drive EDGWARE",
                "number": 2
            },
            "geometry": {
                "type": "Point",
                "coordinates": [
                    -0.26895,
                    51.5974
                ]
            }
        },
        {
            "type": "Feature",
            "properties": {
                "recipient": "Birmingham Repertory Theatre",
                "address": "Broad St Birmingham B1 2EP",
                "number": 1
            },
            "geometry": {
                "type": "Point",
                "coordinates": [
                    -1.91765,
                    52.4733
                ]
            }
        },
        {
            "type": "Feature",
            "properties": {
                "recipient": "Butler & Tanner",
                "address": "Frome Sumer",
                "number": 1
            },
            "geometry": {
                "type": "Point",
                "coordinates": [
                    -2.32067,
                    51.2317
                ]
            }
        },
        {
            "type": "Feature",
            "properties": {
                "recipient": "Curtis Brown",
                "address": "6 Henrietta Street London",
                "number": 1
            },
            "geometry": {
                "type": "Point",
                "coordinates": [
                    -0.123649,
                    51.5111
                ]
            }
        },
        {
            "type": "Feature",
            "properties": {
                "recipient": "Doubleday Doran",
                "address": "13 John Street London",
                "number": 1
            },
            "geometry": {
                "type": "Point",
                "coordinates": [
                    -0.115298,
                    51.5223
                ]
            }
        },
        {
            "type": "Feature",
            "properties": {
                "recipient": "Leonard Woolf",
                "address": "4 King's Bench Walk London",
                "number": 15
            },
            "geometry": {
                "type": "Point",
                "coordinates": [
                    -0.109316,
                    51.5122
                ]
            }
        },
        {
            "type": "Feature",
            "properties": {
                "recipient": "Lowe Brydone Ltd.",
                "address": "101 Park Street London",
                "number": 1
            },
            "geometry": {
                "type": "Point",
                "coordinates": [
                    -0.155552,
                    51.5123
                ]
            }
        },
        {
            "type": "Feature",
            "properties": {
                "recipient": "Messrs. Irwin and Gordon",
                "address": "11 Greenville Street Toronto",
                "number": 2
            },
            "geometry": {
                "type": "Point",
                "coordinates": [
                    -79.3866,
                    43.6615
                ]
            }
        },
        {
            "type": "Feature",
            "properties": {
                "recipient": "Norman Leys",
                "address": "Yalding Kent",
                "number": 16
            },
            "geometry": {
                "type": "Point",
                "coordinates": [
                    0.429,
                    51.224
                ]
            }
        },
        {
            "type": "Feature",
            "properties": {
                "recipient": "Percy Lund Humphreys & Co.",
                "address": "3 Amen Corner London",
                "number": 1
            },
            "geometry": {
                "type": "Point",
                "coordinates": [
                    -0.160445,
                    51.423
                ]
            }
        },
        {
            "type": "Feature",
            "properties": {
                "recipient": "R & R Clark",
                "address": "Brandon Street Edinburgh",
                "number": 2
            },
            "geometry": {
                "type": "Point",
                "coordinates": [
                    -3.2011,
                    55.9607
                ]
            }
        },
        {
            "type": "Feature",
            "properties": {
                "recipient": "the Book Society",
                "address": "40 William IV Street London",
                "number": 1
            },
            "geometry": {
                "type": "Point",
                "coordinates": [
                    -0.126196,
                    51.5096
                ]
            }
        },
        {
            "type": "Feature",
            "properties": {
                "recipient": "The Windmill Press",
                "address": "Tadworth Surrey",
                "number": 1
            },
            "geometry": {
                "type": "Point",
                "coordinates": [
                    -0.232671,
                    51.2912
                ]
            }
        },
        {
            "type": "Feature",
            "properties": {
                "recipient": "Vita Sackville-West",
                "address": "Sissinghurst Castle Kent.",
                "number": 12
            },
            "geometry": {
                "type": "Point",
                "coordinates": [
                    0.577601,
                    51.1167
                ]
            }
        }
    ]
} ;
